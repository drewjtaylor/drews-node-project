module.exports = {
    'mongoUrl' : 'mongodb://localhost:27017/formationdb',
    'secretKey': 'dc4ejqc344fdasdfasdf3fh43nfqvjn23rf2309j1fad',
    'mongoDbName': 'formationdb'
}